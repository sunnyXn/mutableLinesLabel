//
//  NSObject+Tools.m
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "NSObject+Tools.h"

@implementation NSObject (Tools)

BOOL xx_isSafeObj(id _Nullable anObject) {
    
    BOOL res = NO;
    
    if (anObject && ![anObject isKindOfClass:[NSNull class]] && ![anObject isEqual:[NSNull null]]) {
        res = YES;
    }
    
    return res;
}

BOOL isClass_NSNumber(id _Nullable anObject) {
    BOOL res = NO;
    if (xx_isSafeObj(anObject)) {
        if ([anObject isMemberOfClass:NSNumber.class] || [anObject isKindOfClass:NSNumber.class]) {
            res = YES;
        }
    }
    return res;
}

NSString * _Nonnull xx_safeString(id _Nullable anObject) {
    
    if (anObject && xx_isNonemptyString(anObject)) {
        
        return [(NSString *)anObject stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        
    }
    if (anObject && isClass_NSNumber(anObject)) {
        return [NSString stringWithFormat:@"%@",anObject];
    }
    return @"";
}

BOOL xx_isNonemptyString(id _Nullable anObject) {
    BOOL res = NO;
    if (isSafeString(anObject)) {
        NSString *stringTemp = [(NSString *)anObject stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (stringTemp.length) {
            res = YES;
        }
    }
    return res;
}

BOOL isSafeString(id _Nullable anObject) {
    BOOL res = NO;
    if (anObject && xx_isSafeObj(anObject)) {
        if ([anObject isKindOfClass:[NSString class]] || [anObject isKindOfClass:[NSMutableString class]]) {
            NSString *stringTemp = [(NSString *)anObject stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            if ([stringTemp isEqualToString:@"<null>"] || [stringTemp isEqualToString:@"(null)"] || [stringTemp isEqualToString:@"null"]) {
                res = NO;
            } else {
                res = YES;
            }
        }
    }
    return res;
}

@end
