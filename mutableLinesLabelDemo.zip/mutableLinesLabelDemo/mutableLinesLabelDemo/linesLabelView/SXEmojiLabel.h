//
//  SXEmojiLabel.h
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "TTTAttributedLabel.h"


#define kCommentEmojiRangexStr @"\\[([^\\[\\]]+)\\]"

/**
 可以解析显示表情的label， 支持自定义表情检索
*/
@interface SXEmojiLabel : TTTAttributedLabel


@property (nonatomic, assign) BOOL disableEmoji; //禁用表情

@property (nonatomic, strong) NSString *customEmojiRegex; //自定义表情正则

//留个初始副本
@property (nonatomic, strong) id emojiText;


@end


