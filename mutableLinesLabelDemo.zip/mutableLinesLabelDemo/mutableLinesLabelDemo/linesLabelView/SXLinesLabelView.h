//
//  SXLinesLabelView.h
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "SXBaseView.h"


/**
不定行数label，结尾可以设置特殊颜色的文字/点击事件，可折叠/展开
*/
@interface SXLinesLabelView : SXBaseView

@property (nonatomic,strong) NSString *text;

@property (nonatomic,strong) UIFont *font;

@property (nonatomic,strong) UIColor *textColor;

@property (nonatomic,assign) NSInteger numberOfLines;

@property (nonatomic,assign) NSLineBreakMode lineBreakMode;

@property (nonatomic,assign) NSTextAlignment textAlignment;

@property (nonatomic,assign) CGFloat lineSpacing;



/**
 结尾的文字 折叠状态下
 */
@property (nonatomic,strong) NSString *terminalTextFold;

/**
 结尾的文字 展开状态下
 */
@property (nonatomic,strong) NSString *terminalTextSpread;

/**
 结尾文字颜色
 */
@property (nonatomic,strong) UIColor *terminalColor;

/**
 是否展开所有文字，默认折叠
 */
@property (nonatomic,assign) BOOL isSpreadContent;

/**
 是否隐藏结尾
 */
@property (nonatomic,assign) BOOL isHiddenTerminal;

/**
 结尾事件block
 */
@property (nonatomic,copy) void (^terminalBlock)(void);


@end


