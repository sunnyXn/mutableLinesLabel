//
//  UILabel+indeterminate.m
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "UILabel+indeterminate.h"
#import <CoreText/CoreText.h>
#import <objc/runtime.h>


inline NSMutableAttributedString *NSAttributedStringWithHTMLString(NSString *htmlString ,UIFont *font ,CGFloat lineSpacing)
{
    NSDictionary *options = @{ NSDocumentTypeDocumentAttribute : NSHTMLTextDocumentType, NSCharacterEncodingDocumentAttribute :@(NSUTF8StringEncoding) };
    
    NSData *data = [htmlString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithData:data options:options documentAttributes:nil error:nil];
    
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.lineSpacing = lineSpacing;
    style.lineBreakMode = NSLineBreakByCharWrapping;
    [attributedString addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, attributedString.length)];
    [attributedString addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, attributedString.length)];
    
    return attributedString;
}

static inline NSDictionary * NSAttributedStringAttributesFromLabel(UILabel *label) {
    NSMutableDictionary *mutableAttributes = [NSMutableDictionary dictionary];
    
    if ([NSMutableParagraphStyle class]) {
        
        mutableAttributes[(NSString *)kCTFontAttributeName] = label.font;
        mutableAttributes[(NSString *)kCTForegroundColorAttributeName] = label.textColor;
        mutableAttributes[(NSString *)kCTKernAttributeName] = @(label.kern);
        
        
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        paragraphStyle.alignment = label.textAlignment;
        paragraphStyle.lineSpacing = label.lineSpacing;
        
        paragraphStyle.firstLineHeadIndent = label.firstLineIndent;
        
        paragraphStyle.lineHeightMultiple = 1.0;
        
        if (label.numberOfLines == 1) {
            paragraphStyle.lineBreakMode = label.lineBreakMode;
        } else {
            paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
        }
        
        mutableAttributes[(NSString *)kCTParagraphStyleAttributeName] = paragraphStyle;
        
    }
    
    return [NSDictionary dictionaryWithDictionary:mutableAttributes];
}


static inline CGSize CTFramesetterSuggestFrameSizeForAttributedStringWithConstraints(CTFramesetterRef framesetter, NSAttributedString *attributedString, CGSize size, NSUInteger numberOfLines) {
    CFRange rangeToSize = CFRangeMake(0, (CFIndex)[attributedString length]);
    CGSize constraints = CGSizeMake(size.width, MAXFLOAT);
    
    if (numberOfLines == 1) {
        // If there is one line, the size that fits is the full width of the line
        constraints = CGSizeMake(MAXFLOAT, MAXFLOAT);
    } else if (numberOfLines > 0) {
        // If the line count of the label more than 1, limit the range to size to the number of lines that have been set
        CGMutablePathRef path = CGPathCreateMutable();
        CGPathAddRect(path, NULL, CGRectMake(0.0f, 0.0f, constraints.width, MAXFLOAT));
        CTFrameRef frame = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), path, NULL);
        CFArrayRef lines = CTFrameGetLines(frame);
        
        if (CFArrayGetCount(lines) > 0) {
            NSInteger lastVisibleLineIndex = MIN((CFIndex)numberOfLines, CFArrayGetCount(lines)) - 1;
            CTLineRef lastVisibleLine = CFArrayGetValueAtIndex(lines, lastVisibleLineIndex);
            
            CFRange rangeToLayout = CTLineGetStringRange(lastVisibleLine);
            rangeToSize = CFRangeMake(0, rangeToLayout.location + rangeToLayout.length);
        }
        
        CFRelease(frame);
        CFRelease(path);
    }
    
    CGSize suggestedSize = CTFramesetterSuggestFrameSizeWithConstraints(framesetter, rangeToSize, NULL, constraints, NULL);
    
    return CGSizeMake(ceil(suggestedSize.width), ceil(suggestedSize.height));
}


@implementation UILabel (indeterminate)

- (void)setKern:(CGFloat)kern
{
    objc_setAssociatedObject(self, @selector(setKern:), @(kern), OBJC_ASSOCIATION_ASSIGN);
}

- (CGFloat)kern
{
    return [objc_getAssociatedObject(self, @selector(setKern:)) doubleValue];
}

- (void)setLineSpacing:(CGFloat)lineSpacing
{
    objc_setAssociatedObject(self, @selector(setLineSpacing:), @(lineSpacing), OBJC_ASSOCIATION_ASSIGN);
}

- (CGFloat)lineSpacing
{
    return [objc_getAssociatedObject(self, @selector(setLineSpacing:)) doubleValue];
}

- (void)setFirstLineIndent:(CGFloat)firstLineIndent
{
    objc_setAssociatedObject(self, @selector(setFirstLineIndent:), @(firstLineIndent), OBJC_ASSOCIATION_ASSIGN);
}

- (CGFloat)firstLineIndent
{
    return [objc_getAssociatedObject(self, @selector(setFirstLineIndent:)) doubleValue];
}


- (NSDictionary *)attributes
{
    return NSAttributedStringAttributesFromLabel(self);
}


/**
 每行文字高度
 */
- (CGFloat)lineHeight
{
    return self.font.lineHeight;
}

/**
 总行数
 */
- (NSInteger)lineCount
{
    return self.getLinesArrayOfString.count;
}

/**
 固定宽度，无固定高度的总高度
 */
-(CGFloat)labelHeight {
    
    CGSize size = [self.text boundingRectWithSize:CGSizeMake(self.bounds.size.width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:NSAttributedStringAttributesFromLabel(self) context:nil].size;
    
    return size.height;
}

/**
 根据label属性，获得size范围内字符串的高度
 
 @param size 约束范围
 @return size
 */
- (CGSize)sizeThatFitsConstraints:(CGSize)size
{
    NSMutableAttributedString *attributedString = nil;
    if (self.attributedText.length > 0)
    {
        attributedString = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
    }
    else
    {
        attributedString = [[NSMutableAttributedString alloc] initWithString:self.text attributes:NSAttributedStringAttributesFromLabel(self)];
    }
    
    
    if (!attributedString) {
        return CGSizeZero;
    }
    
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)attributedString);
    
    CGSize calculatedSize = CTFramesetterSuggestFrameSizeForAttributedStringWithConstraints(framesetter, attributedString, size, self.numberOfLines);
    
    CFRelease(framesetter);
    
    return calculatedSize;
}

/**
 获取每一行的文字内容组成的数组
 
 @return 每一行文字的数组
 */
- (NSArray *)getLinesArrayOfString
{
    NSMutableAttributedString *attributedString = nil;
    if (self.attributedText.length > 0)
    {
        attributedString = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
    }
    else
    {
        attributedString = [[NSMutableAttributedString alloc] initWithString:self.text attributes:NSAttributedStringAttributesFromLabel(self)];
    }
    
    CTFramesetterRef frameSetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)attributedString);
    
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectMake(0,0,self.bounds.size.width,MAXFLOAT));
    CTFrameRef frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(0, 0), path, NULL);
    NSArray *lines = ( NSArray *)CTFrameGetLines(frame);
    
    NSMutableArray *linesArray = [[NSMutableArray alloc]init];
    for (id line in lines) {
        CTLineRef lineRef = (__bridge  CTLineRef )line;
        CFRange lineRange = CTLineGetStringRange(lineRef);
        NSRange range = NSMakeRange(lineRange.location, lineRange.length);
        NSString *lineString = [self.text substringWithRange:range];
        CFAttributedStringSetAttribute((CFMutableAttributedStringRef)attributedString, lineRange, kCTKernAttributeName, (CFTypeRef)([NSNumber numberWithFloat:0.0]));
        CFAttributedStringSetAttribute((CFMutableAttributedStringRef)attributedString, lineRange, kCTKernAttributeName, (CFTypeRef)([NSNumber numberWithInt:0.0]));
        [linesArray addObject:lineString];
    }
    
    CGPathRelease(path);
    CFRelease( frame );
    CFRelease(frameSetter);
    return (NSArray *)linesArray;
}

@end


@implementation NSObject (indeterminate)

+ (CGSize)sizeThatFitsAttributedString:(NSAttributedString *)attributedString withConstraints:(CGSize)size limitedToNumberOfLines:(NSUInteger)numberOfLines {
    
    if (!attributedString) {
        return CGSizeZero;
    }
    
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)attributedString);
    
    CGSize calculatedSize = CTFramesetterSuggestFrameSizeForAttributedStringWithConstraints(framesetter, attributedString, size, numberOfLines);
    
    CFRelease(framesetter);
    
    return calculatedSize;
}

@end
