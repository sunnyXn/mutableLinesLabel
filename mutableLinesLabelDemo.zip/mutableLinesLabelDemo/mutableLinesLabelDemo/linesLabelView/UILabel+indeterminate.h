//
//  UILabel+indeterminate.h
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import <UIKit/UIKit.h>


extern inline NSMutableAttributedString *NSAttributedStringWithHTMLString(NSString *htmlString ,UIFont *font ,CGFloat lineSpacing);


/**
 label扩展，增加首行缩进、行间距、字间距
 */
@interface UILabel (indeterminate)


/**
 The distance, in points, from the leading margin of a frame to the beginning of the paragraph's first line. This value is always nonnegative, and is 0.0 by default.
 */
@property (nonatomic, assign) CGFloat firstLineIndent;

/**
 The amount to kern the next character. Default is standard kerning. If this attribute is set to 0.0, no kerning is done at all.
 */
@property (nonatomic, assign) CGFloat kern;


/**
 The space in points added between lines within the paragraph. This value is always nonnegative and is 0.0 by default.
 */
@property (nonatomic, assign) CGFloat lineSpacing;


@property (nonatomic, readonly) CGFloat lineHeight;

@property (nonatomic, readonly) CGFloat labelHeight;

@property (nonatomic, readonly) NSInteger lineCount;

@property (nonatomic, strong, readonly) NSDictionary *attributes;

- (NSArray *)getLinesArrayOfString;

- (CGSize)sizeThatFitsConstraints:(CGSize)size;


@end


@interface NSObject (indeterminate)

+ (CGSize)sizeThatFitsAttributedString:(NSAttributedString *)attributedString withConstraints:(CGSize)size limitedToNumberOfLines:(NSUInteger)numberOfLines;


@end


