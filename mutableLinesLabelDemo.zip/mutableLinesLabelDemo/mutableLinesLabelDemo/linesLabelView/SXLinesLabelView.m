//
//  SXLinesLabelView.m
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "SXLinesLabelView.h"
#import "SXEmojiLabel.h"


@interface SXLinesLabelView ()

@property (nonatomic,strong) SXEmojiLabel *lblTitle;
@property (nonatomic,strong) UIButton *btn;

@property (nonatomic,strong) SXEmojiLabel *lblTemp;
@property (nonatomic,strong) NSString *ellipsisString;
@property (nonatomic,assign) CGFloat singleWidth;
@property (nonatomic,assign) CGFloat ellipsisWidth;

@end


@implementation SXLinesLabelView

- (NSString *)replaceString:(NSString *)cutString widthCutWidth:(CGFloat)cutWidth {
    NSString * tempString = xx_safeString(cutString);
    
    CGFloat tempWidth = [self getStringWidthWithString:tempString];
    
    CGFloat gap = tempWidth - cutWidth;
    
    if (gap > 0) {
        CGFloat cutCount = gap/self.singleWidth;
        cutCount = ceil(cutCount);
        while (gap > 0) {
            
            tempString = [tempString substringToIndex:(tempString.length - cutCount)];
            
            tempWidth = [self getStringWidthWithString:tempString];
            gap = tempWidth - cutWidth;
            cutCount = gap/self.singleWidth;
            cutCount = ceil(cutCount);
        }
    } else {
        tempString = @"";
    }
    return tempString;
}

- (CGFloat)getStringWidthWithString:(NSString *)tempString {
    CGFloat width = 0;
    
    self.lblTemp.text = tempString;
    
    width = [self.lblTemp sizeThatFitsConstraints:CGSizeMake(MAXFLOAT, MAXFLOAT)].width;
    
    return width;
}

#pragma  mark - init
- (void)xx_init {
    self.terminalTextFold = @"全文";
    self.terminalTextSpread = @"收起";
    
    self.ellipsisString = @"...";
    self.ellipsisWidth = [self getStringWidthWithString:self.ellipsisString];
    self.singleWidth = [self getStringWidthWithString:@"啊"];
}

- (void)xx_layout {
    
    _lblTitle.text = xx_safeString(_text);
    _lblTitle.numberOfLines = self.isSpreadContent ? (_lblTitle.numberOfLines = 0) : (_lblTitle.numberOfLines = _numberOfLines);
    
    _lblTitle.width = self.width;
    _lblTitle.height = [TTTAttributedLabel sizeThatFitsAttributedString:_lblTitle.attributedText withConstraints:CGSizeMake(_lblTitle.width, MAXFLOAT) limitedToNumberOfLines:_lblTitle.numberOfLines].height;
    
    self.btn.hidden = self.isHiddenTerminal;
    if (!self.isHiddenTerminal) {
        NSString * terminalText = self.isSpreadContent ? _terminalTextSpread : _terminalTextFold;
        
        [_btn setTitle:terminalText forState:UIControlStateNormal];
        _btn.width = [terminalText sizeWithAttributes:@{NSFontAttributeName : _btn.titleLabel.font}].width;
        _btn.left = _lblTitle.width - _btn.width;
        
        NSArray * linesArray = [_lblTitle getLinesArrayOfString];
        
        self.btn.hidden = linesArray.count < _lblTitle.numberOfLines;
        if (!self.btn.isHidden) {
            NSInteger index = _lblTitle.numberOfLines == 0 ? linesArray.count : MIN(_lblTitle.numberOfLines, linesArray.count);
            
            NSString * tempString = linesArray[(index - 1)];
            NSInteger location = 0;
            for ( int i = 0 ; i < (index - 1); i++) {
                NSString * lineString = xx_safeString([linesArray objectAtIndex:i]);
                location += lineString.length;
            }
            
            NSRange tempRange = NSMakeRange(location, tempString.length);
            
            CGFloat tempWidth = [self getStringWidthWithString:tempString];
            
            if (!self.isSpreadContent) {
                tempWidth += self.ellipsisWidth;
            }
            
            CGFloat gap = tempWidth - _btn.left;
            
            
            NSString * cutString = _lblTitle.text;
            cutString = [cutString stringByReplacingCharactersInRange:NSMakeRange(tempRange.location, cutString.length - tempRange.location) withString:@""];
            
            if (gap > 0) {
                CGFloat cutWidth = self.isSpreadContent ? _btn.left : (_btn.left - self.ellipsisWidth);
                
                tempString = [self replaceString:tempString widthCutWidth:cutWidth];
                tempWidth = [self getStringWidthWithString:tempString];
            }
            
            
            if (self.isSpreadContent) {
                _btn.left = _lblTitle.left + tempWidth;
                
                _btn.top = gap > 0 ? (_lblTitle.bottom + 3) : (_lblTitle.bottom - _btn.height - 1.5);
            } else {
                tempString = [tempString stringByAppendingString:self.ellipsisString];
                cutString = [cutString stringByAppendingString:tempString];
                _lblTitle.text = cutString;
                _lblTitle.height = [TTTAttributedLabel sizeThatFitsAttributedString:_lblTitle.attributedText withConstraints:CGSizeMake(_lblTitle.width, MAXFLOAT) limitedToNumberOfLines:_lblTitle.numberOfLines].height;
                
                _btn.left = _lblTitle.left + tempWidth + self.ellipsisWidth;
                _btn.top = _lblTitle.bottom - _btn.height - 2.0;
            }
        } else {
            _lblTitle.height = [TTTAttributedLabel sizeThatFitsAttributedString:_lblTitle.attributedText withConstraints:CGSizeMake(_lblTitle.width, MAXFLOAT) limitedToNumberOfLines:_lblTitle.numberOfLines].height;
        }
    } else {
        _lblTitle.height = [TTTAttributedLabel sizeThatFitsAttributedString:_lblTitle.attributedText withConstraints:CGSizeMake(_lblTitle.width, MAXFLOAT) limitedToNumberOfLines:_lblTitle.numberOfLines].height;
    }
    
    self.height = !_btn.isHidden ? MAX(_btn.bottom, _lblTitle.bottom) : _lblTitle.bottom;
}


#pragma  mark - get
- (SXEmojiLabel *)lblTitle {
    if (!_lblTitle) {
        _lblTitle = [[SXEmojiLabel alloc] initWithFrame:self.bounds];
        _lblTitle.font = [UIFont systemFontOfSize:14];
        _lblTitle.numberOfLines = 3;
        _lblTitle.lineSpacing = 6;
        _lblTitle.verticalAlignment = TTTAttributedLabelVerticalAlignmentTop;
        _lblTitle.textColor = HEXColor(0x666666);
        
        _lblTitle.customEmojiRegex = kCommentEmojiRangexStr;
        
        [self addSubview:_lblTitle];
    }
    return _lblTitle;
}

- (UIButton *)btn {
    if (!_btn) {
        _btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btn setTitleColor:HEXColor(0x5188A6) forState:UIControlStateNormal];
        [_btn setTitle:@"全文" forState:UIControlStateNormal];
        _btn.titleLabel.font = [UIFont systemFontOfSize:14];
        _btn.height = 14;
        [_btn addTarget:self action:@selector(actionClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_btn];
    }
    return _btn;
}

- (SXEmojiLabel *)lblTemp {
    if (!_lblTemp) {
        _lblTemp = [[SXEmojiLabel alloc] initWithFrame:self.bounds];
        _lblTemp.font = [UIFont systemFontOfSize:14];
        _lblTemp.numberOfLines = 3;
        _lblTemp.lineSpacing = 6;
        _lblTemp.verticalAlignment = TTTAttributedLabelVerticalAlignmentTop;
        _lblTemp.textColor = HEXColor(0x666666);
        
        _lblTemp.customEmojiRegex = kCommentEmojiRangexStr;
    }
    return _lblTemp;
}

#pragma  mark - set
- (void)setText:(NSString *)text {
    _text = xx_safeString(text);
    self.lblTitle.text = _text;
}

- (void)setFont:(UIFont *)font {
    _font = font;
    self.lblTitle.font = _font;
    self.lblTemp.font = _font;
}

- (void)setTextColor:(UIColor *)textColor {
    _textColor = textColor;
    self.lblTitle.textColor = _textColor;
}

- (void)setNumberOfLines:(NSInteger)numberOfLines {
    _numberOfLines = numberOfLines;
    self.lblTitle.numberOfLines = _numberOfLines;
    self.lblTemp.numberOfLines = _numberOfLines;
}

- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode {
    _lineBreakMode = lineBreakMode;
    self.lblTitle.lineBreakMode = _lineBreakMode;
    self.lblTemp.lineBreakMode = _lineBreakMode;
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment {
    _textAlignment = textAlignment;
    self.lblTitle.textAlignment = _textAlignment;
    self.lblTemp.textAlignment = _textAlignment;
}

- (void)setLineSpacing:(CGFloat)lineSpacing {
    _lineSpacing = lineSpacing;
    self.lblTitle.lineSpacing = _lineSpacing;
    self.lblTemp.lineSpacing = _lineSpacing;
}

- (void)setTerminalTextFold:(NSString *)terminalTextFold {
    _terminalTextFold = xx_safeString(terminalTextFold);
}

- (void)setTerminalTextSpread:(NSString *)terminalTextSpread {
    _terminalTextSpread = xx_safeString(terminalTextSpread);
}

- (void)setTerminalColor:(UIColor *)terminalColor {
    _terminalColor = terminalColor;
    [self.btn setTitleColor:_terminalColor forState:UIControlStateNormal];
}

- (void)setIsSpreadContent:(BOOL)isSpreadContent {
    _isSpreadContent = isSpreadContent;
    [self xx_layout];
}

#pragma  mark - action
- (void)actionClick:(UIButton *)s {
    if (self.terminalBlock)  self.terminalBlock();
}

@end
