//
//  SXBaseView.m
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "SXBaseView.h"


@interface SXBaseView ()

@property (nonatomic, assign) BOOL hasInitialized;

@end


@implementation SXBaseView

#pragma mark - life cycle -
- (void)dealloc {
    //NSLog(@"%@  基类:%s", NSStringFromClass([self class]), __FUNCTION__);
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self __xx_baseClass_initialize];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self __xx_baseClass_initialize];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self __xx_baseClass_initialize];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    [self __xx_baseClass_awakeFromNib];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self __xx_baseClass_layout];
}

#pragma mark - private -
- (void)__xx_baseClass_initialize {
    if (self.hasInitialized) {
        return;
    }
    self.hasInitialized = YES;
    
    //NSLog(@"%@  基类:%s", NSStringFromClass([self class]), __FUNCTION__);
    self.clipsToBounds = YES;
    
    [self xx_init];
}

- (void)__xx_baseClass_awakeFromNib {
    [self xx_awakeFromNib];
}

- (void)__xx_baseClass_layout {
    [self xx_layout];
}

#pragma mark - getters -

#pragma mark - setters -

#pragma mark - Public override -
- (void)xx_init {
    //NSLog(@"基类  %@  子类  _%s", NSStringFromClass([self class]), __FUNCTION__);
    self.clipsToBounds = YES;
}

- (void)xx_awakeFromNib {
    //NSLog(@"基类  %@  子类  _%s", NSStringFromClass([self class]), __FUNCTION__);
}

- (void)xx_layout {
    //NSLog(@"基类  %@  子类  _%s", NSStringFromClass([self class]), __FUNCTION__);
}

- (void)xx_viewWillAppear:(BOOL)animated {
    //NSLog(@"%s",__FUNCTION__);
}

- (void)xx_viewDidAppear:(BOOL)animated {
    //NSLog(@"%s",__FUNCTION__);
}

- (void)xx_viewWillDisappear:(BOOL)animated {
    //NSLog(@"%s",__FUNCTION__);
}

- (void)xx_viewDidDisappear:(BOOL)animated {
    //NSLog(@"%s",__FUNCTION__);
}

#pragma mark - events -

#pragma mark - public -

@end
