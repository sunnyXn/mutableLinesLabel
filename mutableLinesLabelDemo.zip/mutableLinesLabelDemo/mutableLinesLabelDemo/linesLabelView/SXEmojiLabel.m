//
//  SXEmojiLabel.m
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "SXEmojiLabel.h"


#define kEmojiReplaceCharacter @"\uFFFC"

NSString *const kCustomGlyphAttributeImageName = @"CustomGlyphAttributeImageName";

static inline CGFloat TTTFlushFactorForTextAlignment(NSTextAlignment textAlignment) {
    switch (textAlignment) {
        case NSTextAlignmentCenter:
            return 0.5f;
        case NSTextAlignmentRight:
            return 1.0f;
        case NSTextAlignmentLeft:
        default:
            return 0.0f;
    }
}

#pragma mark - 表情 callback
typedef struct CustomGlyphMetrics {
    CGFloat ascent;
    CGFloat descent;
    CGFloat width;
} CustomGlyphMetrics, *CustomGlyphMetricsRef;

static void deallocCallback(void *refCon) {
    (void)(free(refCon)), refCon = NULL;
}

static CGFloat ascentCallback(void *refCon) {
    CustomGlyphMetricsRef metrics = (CustomGlyphMetricsRef)refCon;
    return metrics->ascent;
}

static CGFloat descentCallback(void *refCon) {
    CustomGlyphMetricsRef metrics = (CustomGlyphMetricsRef)refCon;
    return metrics->descent;
}

static CGFloat widthCallback(void *refCon) {
    CustomGlyphMetricsRef metrics = (CustomGlyphMetricsRef)refCon;
    return metrics->width;
}


@interface TTTAttributedLabel (ZDMFollowEmojiLabel)

- (void)commonInit;
- (void)drawStrike:(CTFrameRef)frame
            inRect:(CGRect)rect
           context:(CGContextRef)c;

@end

@interface SXEmojiLabel ()

@property (nonatomic, strong) NSRegularExpression *customEmojiRegularExpression;
@property (nonatomic, assign) BOOL ignoreSetText;

@end



@implementation SXEmojiLabel

- (void)commonInit {
    [super commonInit];
}

#pragma mark - 绘制表情
- (void)drawStrike:(CTFrameRef)frame
            inRect:(CGRect)rect
           context:(CGContextRef)c {
    [super drawStrike:frame inRect:rect context:c];
    
    CGFloat emojiWith = self.font.lineHeight;
    
    //修正绘制offset，根据当前设置的textAlignment
    CGFloat flushFactor = TTTFlushFactorForTextAlignment(self.textAlignment);
    
    CFArrayRef lines = CTFrameGetLines(frame);
    NSInteger numberOfLines = self.numberOfLines > 0 ? MIN(self.numberOfLines, CFArrayGetCount(lines)) : CFArrayGetCount(lines);
    CGPoint lineOrigins[numberOfLines];
    CTFrameGetLineOrigins(frame, CFRangeMake(0, numberOfLines), lineOrigins);
    
    BOOL truncateLastLine = (self.lineBreakMode == NSLineBreakByTruncatingHead || self.lineBreakMode == NSLineBreakByTruncatingMiddle || self.lineBreakMode == NSLineBreakByTruncatingTail);
    CFRange textRange = CFRangeMake(0, (CFIndex)[self.attributedText length]);
    
    for (CFIndex lineIndex = 0; lineIndex < numberOfLines; lineIndex++) {
        CTLineRef line = CFArrayGetValueAtIndex(lines, lineIndex);
        
        CGPoint lineOrigin = lineOrigins[lineIndex];
        
        //这里其实是能获取到当前行的真实origin.x，根据textAlignment，而lineBounds.origin.x其实是默认一直为0的(不会受textAlignment影响)
        CGFloat penOffset = (CGFloat)CTLineGetPenOffsetForFlush(line, flushFactor, rect.size.width);
        
        CFIndex truncationAttributePosition = -1;
        //检测如果是最后一行，是否有替换...
        if (lineIndex == numberOfLines - 1 && truncateLastLine) {
            // Check if the range of text in the last line reaches the end of the full attributed string
            CFRange lastLineRange = CTLineGetStringRange(line);
            
            if (!(lastLineRange.length == 0 && lastLineRange.location == 0) && lastLineRange.location + lastLineRange.length < textRange.location + textRange.length) {
                // Get correct truncationType and attribute position
                truncationAttributePosition = lastLineRange.location;
                NSLineBreakMode lineBreakMode = self.lineBreakMode;
                
                // Multiple lines, only use UILineBreakModeTailTruncation
                if (numberOfLines != 1) {
                    lineBreakMode = NSLineBreakByTruncatingTail;
                }
                
                switch (lineBreakMode) {
                    case NSLineBreakByTruncatingHead:
                        break;
                    case NSLineBreakByTruncatingMiddle:
                        truncationAttributePosition += (lastLineRange.length / 2);
                        break;
                    case NSLineBreakByTruncatingTail:
                    default:
                        truncationAttributePosition += (lastLineRange.length - 1);
                        break;
                }
                
                //如果要在truncationAttributePosition这个位置画表情需要忽略
            }
        }
        
        //找到当前行的每一个要素，姑且这么叫吧。可以理解为有单独的attr属性的各个range。
        for (id glyphRun in (__bridge NSArray *)CTLineGetGlyphRuns(line)) {
            //找到此要素所对应的属性
            NSDictionary *attributes = (__bridge NSDictionary *)CTRunGetAttributes((__bridge CTRunRef) glyphRun);
            //判断是否有图像，如果有就绘制上去
            NSString *imageName = attributes[kCustomGlyphAttributeImageName];
            CTRunDelegateRef delegate = (__bridge CTRunDelegateRef)[attributes valueForKey:(id)kCTRunDelegateAttributeName];
            if (imageName) {
                CFRange glyphRange = CTRunGetStringRange((__bridge CTRunRef)glyphRun);
                if (glyphRange.location == truncationAttributePosition) {
                    //这里因为glyphRange的length肯定为1，所以只做这一个判断足够
                    continue;
                }
                
                if (nil == delegate) {
                    continue;
                }
                
                CGRect runBounds = CGRectZero;
                CGFloat runAscent = 0.0f;
                CGFloat runDescent = 0.0f;
                
                runBounds.size.width = (CGFloat)CTRunGetTypographicBounds((__bridge CTRunRef)glyphRun, CFRangeMake(0, 0), &runAscent, &runDescent, NULL);
                
                if (runBounds.size.width!=emojiWith) {
                    //这一句是为了在某些情况下，例如单行省略号模式下，默认行为会将个别表情的runDelegate改变，也就改变了其大小。这时候会引起界面上错乱，这里做下检测(浮点数做等于判断似乎有点操蛋啊。。)
                    continue;
                }
                
                runBounds.size.height = runAscent + runDescent;
                
                CGFloat xOffset = 0.0f;
                switch (CTRunGetStatus((__bridge CTRunRef)glyphRun)) {
                    case kCTRunStatusRightToLeft:
                        xOffset = CTLineGetOffsetForStringIndex(line, glyphRange.location + glyphRange.length, NULL);
                        break;
                    default:
                        xOffset = CTLineGetOffsetForStringIndex(line, glyphRange.location, NULL);
                        break;
                }
                runBounds.origin.x = penOffset + xOffset;
                runBounds.origin.y = lineOrigin.y - runDescent;
                
                
                if (lineIndex == 0) {
                    runBounds.origin.x += self.firstLineIndent;
                }
                
                UIImage *image = [UIImage imageNamed:imageName];
                
                
                if (image.size.width < runBounds.size.width && image.size.height < runBounds.size.height) {
                    CGFloat imgWidth = runBounds.size.width;
                    CGFloat imgHei = runBounds.size.height;
                    runBounds.size = image.size;
                    
                    CGFloat gap = (imgWidth - image.size.width) * 0.5;
                    runBounds.origin.x += gap;
                    
                    gap = (imgHei - image.size.height) * 0.5;
                    runBounds.origin.y += gap;
                    
                } else {
                    if (image.size.width > image.size.height) {
                        CGFloat imgHei = image.size.height/image.size.width * runBounds.size.height;
                        CGFloat gap = (runAscent + runDescent - imgHei) * 0.5;
                        runBounds.origin.y += gap;
                        runBounds.size.height = imgHei;
                    } else if (image.size.height > image.size.width) {
                        CGFloat imgwidth = image.size.width / image.size.height * runBounds.size.height;
                        CGFloat gap = (runBounds.size.width - imgwidth) * 0.5;
                        runBounds.origin.x += gap;
                        runBounds.size.width = imgwidth;
                    }
                }
                CGContextDrawImage(c, runBounds, image.CGImage);
            }
        }
    }
}


#pragma mark - main
/**
 *  返回经过表情识别处理的Attributed字符串
 */
- (NSMutableAttributedString*)mutableAttributeStringWithEmojiText:(NSAttributedString *)emojiText {
    NSArray *emojis = nil;
    
    if (self.customEmojiRegularExpression) {
        //自定义表情正则
        emojis = [self.customEmojiRegularExpression matchesInString:emojiText.string
                                                            options:NSMatchingWithTransparentBounds
                                                              range:NSMakeRange(0, [emojiText length])];
    }
    
    NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] init];
    NSUInteger location = 0;
    
    
    CGFloat emojiWith = self.font.lineHeight;
    for (NSTextCheckingResult *result in emojis) {
        NSRange range = result.range;
        NSAttributedString *attSubStr = [emojiText attributedSubstringFromRange:NSMakeRange(location, range.location - location)];
        [attrStr appendAttributedString:attSubStr];
        
        location = range.location + range.length;
        
        NSAttributedString *emojiKey = [emojiText attributedSubstringFromRange:range];
        
        //如果当前获得key后面有多余的，这个需要记录下
        NSAttributedString *otherAppendStr = nil;
        
        NSString *imageName = emojiKey.string;
        if (imageName) {
            // 这里不用空格，空格有个问题就是连续空格的时候只显示在一行
            NSMutableAttributedString *replaceStr = [[NSMutableAttributedString alloc] initWithString:kEmojiReplaceCharacter];
            NSRange __range = NSMakeRange([attrStr length], 1);
            [attrStr appendAttributedString:replaceStr];
            if (otherAppendStr) { //有其他需要添加的
                [attrStr appendAttributedString:otherAppendStr];
            }
            
            // 定义回调函数
            CTRunDelegateCallbacks callbacks;
            callbacks.version = kCTRunDelegateCurrentVersion;
            callbacks.getAscent = ascentCallback;
            callbacks.getDescent = descentCallback;
            callbacks.getWidth = widthCallback;
            callbacks.dealloc = deallocCallback;
            
            // 这里设置下需要绘制的图片的大小，这里我自定义了一个结构体以便于存储数据
            CustomGlyphMetricsRef metrics = malloc(sizeof(CustomGlyphMetrics));
            metrics->width = emojiWith;
            metrics->ascent = 1/(1+0.25)*metrics->width;
            metrics->descent = metrics->ascent*0.25;
            CTRunDelegateRef delegate = CTRunDelegateCreate(&callbacks, metrics);
            [attrStr addAttribute:(NSString *)kCTRunDelegateAttributeName
                            value:(__bridge id)delegate
                            range:__range];
            CFRelease(delegate);
            
            // 设置自定义属性，绘制的时候需要用到
            [attrStr addAttribute:kCustomGlyphAttributeImageName
                            value:imageName
                            range:__range];
        } else {
            [attrStr appendAttributedString:emojiKey];
        }
    }
    
    if (location < [emojiText length]) {
        NSRange range = NSMakeRange(location, [emojiText length] - location);
        NSAttributedString *attrSubStr = [emojiText attributedSubstringFromRange:range];
        [attrStr appendAttributedString:attrSubStr];
    }
    return attrStr;
}


- (void)setText:(id)text {
    NSParameterAssert(!text || [text isKindOfClass:[NSAttributedString class]] || [text isKindOfClass:[NSString class]]);
    
    if (self.ignoreSetText) {
        [super setText:text];
        return;
    }
    
    if (!text) {
        self.emojiText = nil;
        [super setText:nil];
        return;
    }
    
    //记录下原始的留作备份使用
    self.emojiText = text;
    
    NSMutableAttributedString *mutableAttributedString = nil;
    
    if (self.disableEmoji) {
        mutableAttributedString = [text isKindOfClass:[NSAttributedString class]]?[text mutableCopy]:[[NSMutableAttributedString alloc]initWithString:text];
        //直接设置text即可,这里text可能为attrString，也可能为String,使用TTT的默认行为
        [super setText:text];
    } else {
        //如果是String，必须通过setText:afterInheritingLabelAttributesAndConfiguringWithBlock:来添加一些默认属性，例如字体颜色。这是TTT的做法，不可避免
        if([text isKindOfClass:[NSString class]]) {
            mutableAttributedString = [self mutableAttributeStringWithEmojiText:[[NSAttributedString alloc] initWithString:text]];
            //这里面会调用 self setText:，所以需要做个标记避免下无限循环
            self.ignoreSetText = YES;
            [super setText:mutableAttributedString afterInheritingLabelAttributesAndConfiguringWithBlock:nil];
            self.ignoreSetText = NO;
        } else {
            mutableAttributedString = [self mutableAttributeStringWithEmojiText:text];
            //这里虽然会调用
            [super setText:mutableAttributedString];
        }
    }
}


- (void)setCustomEmojiRegex:(NSString *)customEmojiRegex {
    _customEmojiRegex = customEmojiRegex;
    
    if (customEmojiRegex&&customEmojiRegex.length>0) {
        self.customEmojiRegularExpression = [[NSRegularExpression alloc] initWithPattern:_customEmojiRegex options:NSRegularExpressionCaseInsensitive error:nil];
        NSAssert(self.customEmojiRegularExpression,@"正则（%@）错误",_customEmojiRegex);
    } else {
        self.customEmojiRegularExpression = nil;
    }
    
    self.text = self.emojiText; //简单重新绘制处理下
}

- (void)setDisableEmoji:(BOOL)disableEmoji {
    _disableEmoji = disableEmoji;
    self.text = self.emojiText; //简单重新绘制处理下
}



@end
