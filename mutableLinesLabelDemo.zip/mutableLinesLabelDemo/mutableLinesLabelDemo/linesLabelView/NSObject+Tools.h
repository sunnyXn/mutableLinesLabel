//
//  NSObject+Tools.h
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import <Foundation/Foundation.h>


#define HEXColor(hexColor)  UIColorFromRGB(hexColor)
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]



@interface NSObject (Tools)


BOOL xx_isSafeObj(id _Nullable anObject);
BOOL xx_isNonemptyString(id _Nullable anObject);

NSString * _Nonnull xx_safeString(id _Nullable anObject);


@end


