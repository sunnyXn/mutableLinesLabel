//
//  ViewController.m
//  mutableLinesLabelDemo
//
//  Created by Sunny on 2020/7/23.
//  Copyright © 2020 Sunny. All rights reserved.
//

#import "ViewController.h"
#import "SXLinesLabelView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    SXLinesLabelView * _lblContent = [[SXLinesLabelView alloc] initWithFrame:CGRectMake(10, 100, self.view.width - 20, 15)];
    _lblContent.font = [UIFont systemFontOfSize:14];
    _lblContent.textColor = HEXColor(0x666666);
    _lblContent.numberOfLines = 3;
    _lblContent.lineSpacing = 6;

    _lblContent.terminalTextFold = @"全文";
    _lblContent.terminalColor = HEXColor(0x5188A6);
    _lblContent.backgroundColor = [UIColor whiteColor];

    __weak typeof(_lblContent) weakContent = _lblContent;
    _lblContent.terminalBlock = ^{
        weakContent.isSpreadContent = !weakContent.isSpreadContent;
        [weakContent xx_layout];
    };

    [self.view addSubview:_lblContent];

    _lblContent.text = @"保全手机评测团：ROG游戏手机2 详细测评，全855Plus处理器性能登顶，全能系统 https://www.baidu.com/news 耳目一新的现在互联网套餐控件就是手机频道这里面的问题很多都是无法解决的";

    [_lblContent  xx_layout];
    
}


@end
